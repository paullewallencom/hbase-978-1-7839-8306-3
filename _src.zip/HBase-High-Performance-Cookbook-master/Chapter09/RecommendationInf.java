public interface RecommendationInf {
 public static String DATA_FILE_LOCATION = "data/u.txt";
 public static String DATA_NEW_FILE_LOCATION = "data/myu.txt";
 public static int NUMBER_OF_RECORDS=8;
 public static int NUMBER_IN_A_BATCH=16;
}
