public interface MahoutClusterIntrface {
  
  public static final String coreSiteXML = "/usr/local/hadoop/conf/core-site.xml";
  public static final String hdfsSiteXML ="/usr/local/hadoop/conf/hdfs-site.xml";
  public static final String inpFile = "chapter10/k-meancluster-input/chap10-kmean.txt";
  public static final String outFile = "clustering_seq/";
  public static final String clustringOut ="clustering_output";
  public static final String clustringInital ="clustering_initial/part-00000";

} 
